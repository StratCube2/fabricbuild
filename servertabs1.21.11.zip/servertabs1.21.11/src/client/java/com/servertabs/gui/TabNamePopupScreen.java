package com.servertabs.gui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;

import java.util.function.Consumer;

public class TabNamePopupScreen extends Screen {

    private static final int POPUP_W = 180;
    private static final int POPUP_H = 76;

    private final Screen           parent;
    private final String           initial;
    private final Consumer<String> onConfirm;

    private EditBox nameField;

    public TabNamePopupScreen(Screen parent, String title,
                              String initial, Consumer<String> onConfirm) {
        super(Component.literal(title));
        this.parent    = parent;
        this.initial   = initial != null ? initial : "";
        this.onConfirm = onConfirm;
    }

    @Override
    protected void init() {
        int px = (this.width  - POPUP_W) / 2;
        int py = (this.height - POPUP_H) / 2;

        nameField = new EditBox(this.font,
                px + 8, py + 22, POPUP_W - 16, 16,
                Component.literal("Tab name"));
        nameField.setMaxLength(32);
        nameField.setValue(initial);
        nameField.setFocused(true);
        this.addRenderableWidget(nameField);

        this.addRenderableWidget(Button.builder(
                Component.literal("OK"),
                btn -> confirm())
                .bounds(px + 8, py + 46, 76, 18)
                .build());

        this.addRenderableWidget(Button.builder(
                Component.literal("Cancel"),
                btn -> this.minecraft.setScreen(parent))
                .bounds(px + 96, py + 46, 76, 18)
                .build());
    }

    private void confirm() {
        String value = nameField.getValue().trim();
        if (!value.isEmpty()) {
            onConfirm.accept(value);
        }
        this.minecraft.setScreen(parent);
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float pt) {
        super.renderBackground(g, mx, my, pt); 

        int px = (this.width  - POPUP_W) / 2;
        int py = (this.height - POPUP_H) / 2;

        g.fill(px, py, px + POPUP_W, py + POPUP_H, 0xEE1A1A1A);
        g.fill(px,               py,               px + POPUP_W,     py + 1,            0xFF777777);
        g.fill(px,               py + POPUP_H - 1, px + POPUP_W,     py + POPUP_H,      0xFF777777);
        g.fill(px,               py,               px + 1,            py + POPUP_H,      0xFF777777);
        g.fill(px + POPUP_W - 1, py,               px + POPUP_W,     py + POPUP_H,      0xFF777777);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        super.render(g, mx, my, pt); 

        int py = (this.height - POPUP_H) / 2;
        g.drawCenteredString(this.font, this.title, this.width / 2, py + 8, 0xFF000000 | 0xFFFFFF);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int keyCode = event.key();
        if (keyCode == 257 || keyCode == 335) { 
            confirm();
            return true;
        }
        if (keyCode == 256) { 
            this.minecraft.setScreen(parent);
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false; 
    }
}