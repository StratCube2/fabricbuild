--- START OF FILE servertabs1.21.11/src/client/java/com/servertabs/gui/TabDropdownController.java ---
package com.servertabs.gui;

import com.servertabs.TabConfig;
import com.servertabs.TabEntry;
import com.servertabs.TabSessionState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.multiplayer.ServerSelectionList;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.ServerList;
import net.minecraft.network.chat.Component;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import org.lwjgl.glfw.GLFW;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class TabDropdownController {

    private static final int  PANEL_WIDTH       = 120;
    private static final int  PANEL_PAD         = 5;
    private static final int  TAB_HEIGHT        = 20;
    private static final int  TAB_GAP           = 3;
    private static final int  EASTER_EGG_CLICKS = 10;
    private static final int  CB_SIZE           = 10;
    private static final int  CB_MARGIN         = 4;   
    private static final int  SERVER_ROW_H      = 36;  

    private final Screen screen;
    private boolean panelOpen     = false;
    private float   slideProgress = 0f;
    private String  activeTabId;
    private int     clickCount    = 0;

    private Button  toggleButton;
    private Button  deselectAllButton;

    private boolean     quickAssignMode    = false;
    private String      quickAssignTabId   = null;
    private Set<String> quickAssignChecked = new HashSet<>();

    public TabDropdownController(Screen screen) {
        this.screen      = screen;
        this.activeTabId = TabSessionState.getActiveTabId();
    }

    public void setupWidgets(Screen screen) {
        panelOpen     = false;
        slideProgress = 0f;

        // Cleanup previous buttons to prevent duplicates breaking visibility logic
        Screens.getButtons(screen).removeIf(b -> {
            String text = b.getMessage().getString();
            return text.startsWith("Tabs ") || text.equals("Deselect All") || text.equals("Done \u2713");
        });

        toggleButton = Button.builder(
                Component.literal("Tabs \u2193"),
                btn -> {
                    if (quickAssignMode) {
                        commitQuickAssign();
                        return;
                    }
                    if (!TabConfig.getInstance().isDropdownEnabled()) return;
                    panelOpen = !panelOpen;
                    refreshToggleLabel();

                    clickCount++;
                    if (clickCount >= EASTER_EGG_CLICKS) {
                        clickCount = 0;
                        Minecraft.getInstance().setScreen(new EasterEggScreen(screen));
                    }
                })
                .bounds(4, 4, 60, 20)
                .build();

        deselectAllButton = Button.builder(
                Component.literal("Deselect All"),
                btn -> {
                    quickAssignChecked.clear();
                })
                .bounds(68, 4, 80, 20)
                .build();
        deselectAllButton.visible = false;

        Screens.getButtons(screen).add(toggleButton);
        Screens.getButtons(screen).add(deselectAllButton);
        refreshToggleLabel();
    }

    public void switchTab(int delta) {
        if (quickAssignMode) return; 
        List<TabEntry> tabs = TabConfig.getInstance().getTabs();
        if (tabs.isEmpty()) return;

        int currentIdx = 0;
        for (int i = 0; i < tabs.size(); i++) {
            if (tabs.get(i).getId().equals(activeTabId)) { currentIdx = i; break; }
        }

        int newIdx  = Math.floorMod(currentIdx + delta, tabs.size());
        activeTabId = tabs.get(newIdx).getId();
        TabSessionState.setActiveTabId(activeTabId);
        clickCount  = 0;
        panelOpen   = false;
        refreshToggleLabel();
        applyTabFilter((JoinMultiplayerScreen) screen, activeTabId);
    }

    public void onRender(Screen s, GuiGraphics gfx, int mouseX, int mouseY, float delta) {
        if (quickAssignMode) {
            renderQuickAssignOverlay(gfx, mouseX, mouseY);
            return; 
        }

        float speed = TabConfig.getInstance().getTransitionSpeed().value;
        slideProgress = panelOpen ? Math.min(1f, slideProgress + speed) : Math.max(0f, slideProgress - speed);
        if (slideProgress <= 0f) return;
        if (!TabConfig.getInstance().isDropdownEnabled()) { panelOpen = false; slideProgress = 0f; return; }

        float ease   = easeInOut(slideProgress);
        int   panelX = Math.round((ease - 1f) * PANEL_WIDTH);
        int   panelTop = 28;

        List<TabEntry> tabs    = TabConfig.getInstance().getTabs();
        int            tabAreaH = tabs.size() * (TAB_HEIGHT + TAB_GAP) - TAB_GAP;
        int            panelH  = PANEL_PAD * 2 + tabAreaH;

        gfx.fill(panelX, panelTop, panelX + PANEL_WIDTH, panelTop + panelH, 0xC8101010);
        int border = 0xFF555555;
        gfx.fill(panelX, panelTop, panelX + PANEL_WIDTH, panelTop + 1, border);
        gfx.fill(panelX, panelTop + panelH - 1, panelX + PANEL_WIDTH, panelTop + panelH, border);
        gfx.fill(panelX + PANEL_WIDTH - 1, panelTop, panelX + PANEL_WIDTH, panelTop + panelH, border);

        for (int i = 0; i < tabs.size(); i++) {
            TabEntry tab  = tabs.get(i);
            int tabX = panelX + PANEL_PAD;
            int tabY = panelTop + PANEL_PAD + i * (TAB_HEIGHT + TAB_GAP);
            int tabW = PANEL_WIDTH - PANEL_PAD * 2;

            boolean isActive  = tab.getId().equals(activeTabId);
            boolean isHovered = mouseX >= tabX && mouseX < tabX + tabW && mouseY >= tabY && mouseY < tabY + TAB_HEIGHT;

            int bgColor = isActive  ? 0xFF3A5C3A : isHovered ? 0xFF2E3A58 : 0xFF222222;
            gfx.fill(tabX, tabY, tabX + tabW, tabY + TAB_HEIGHT, bgColor);

            int borderC = isActive ? 0xFF66BB66 : 0xFF404040;
            gfx.fill(tabX, tabY, tabX + tabW, tabY + 1, borderC);
            gfx.fill(tabX, tabY + TAB_HEIGHT - 1, tabX + tabW, tabY + TAB_HEIGHT, borderC);
            gfx.fill(tabX, tabY, tabX + 1, tabY + TAB_HEIGHT, borderC);
            gfx.fill(tabX + tabW - 1, tabY, tabX + tabW, tabY + TAB_HEIGHT, borderC);

            gfx.drawString(Minecraft.getInstance().font, tab.getName(), tabX + 6, tabY + (TAB_HEIGHT - 8) / 2, isActive ? 0xFF000000 | 0xFFFFFF : 0xFF000000 | 0xAAAAAA, false);

            if (isHovered && !isActive && !tab.isLocked() && "all".equals(activeTabId)) {
                gfx.drawString(Minecraft.getInstance().font, "[Alt]", tabX + tabW - 28, tabY + (TAB_HEIGHT - 8) / 2, 0xFF000000 | 0x777777, false);
            }
        }
    }

    private void renderQuickAssignOverlay(GuiGraphics gfx, int mouseX, int mouseY) {
        JoinMultiplayerScreen jms = (JoinMultiplayerScreen) screen;
        ServerSelectionList   ssl = jms.serverSelectionList;
        if (ssl == null) return;

        TabEntry target = TabConfig.getInstance().getTabs().stream().filter(t -> t.getId().equals(quickAssignTabId)).findFirst().orElse(null);
        String header = "Quick Assign \u2192 " + (target != null ? target.getName() : "?");
        gfx.drawString(Minecraft.getInstance().font, header, 4, 30, 0xFF000000 | 0xFFDD44, false);

        for (int i = 0; i < ssl.children().size(); i++) {
            ServerData sd = jms.servers.get(i);
            if (sd == null) continue;

            int rowTop = ssl.getRowTop(i);
            int cbX    = ssl.getX() + CB_MARGIN;
            int cbY    = rowTop + (SERVER_ROW_H - CB_SIZE) / 2;

            boolean checked = quickAssignChecked.contains(normalise(sd.ip));
            boolean hovered = mouseX >= cbX && mouseX < cbX + CB_SIZE && mouseY >= cbY && mouseY < cbY + CB_SIZE;

            int borderCol = hovered ? 0xFF99BBFF : 0xFF888888;
            gfx.fill(cbX, cbY, cbX + CB_SIZE, cbY + CB_SIZE, borderCol);
            gfx.fill(cbX + 1, cbY + 1, cbX + CB_SIZE - 1, cbY + CB_SIZE - 1, checked ? 0xFF44AA44 : 0xFF1A1A1A);

            if (checked) {
                gfx.fill(cbX + 2, cbY + 5, cbX + 4, cbY + CB_SIZE - 1, 0xFFFFFFFF);
                gfx.fill(cbX + 3, cbY + 2, cbX + CB_SIZE - 1, cbY + 5, 0xFFFFFFFF);
            }
        }
    }

    public boolean onMouseClick(Screen s, MouseButtonEvent event) {
        double mouseX = event.x();
        double mouseY = event.y();
        int button = event.button();

        if (quickAssignMode) return handleQuickAssignClick(mouseX, mouseY, button);
        if (slideProgress <= 0f) return true;

        float ease   = easeInOut(slideProgress);
        int   panelX = Math.round((ease - 1f) * PANEL_WIDTH);
        int   panelTop = 28;

        List<TabEntry> tabs = TabConfig.getInstance().getTabs();

        for (int i = 0; i < tabs.size(); i++) {
            int tabX = panelX + PANEL_PAD;
            int tabY = panelTop + PANEL_PAD + i * (TAB_HEIGHT + TAB_GAP);
            int tabW = PANEL_WIDTH - PANEL_PAD * 2;

            if (mouseX >= tabX && mouseX < tabX + tabW && mouseY >= tabY && mouseY < tabY + TAB_HEIGHT) {
                TabEntry clicked = tabs.get(i);
                
                boolean altPressed = isAltDownFallback();

                if (altPressed && !clicked.isLocked() && "all".equals(activeTabId)) {
                    enterQuickAssign(clicked.getId());
                    return false;
                }
                activeTabId = clicked.getId();
                TabSessionState.setActiveTabId(activeTabId);
                panelOpen   = false;
                clickCount  = 0;
                refreshToggleLabel();
                applyTabFilter((JoinMultiplayerScreen) screen, activeTabId);
                return false;
            }
        }
        return true;
    }

    private boolean handleQuickAssignClick(double mouseX, double mouseY, int button) {
        JoinMultiplayerScreen jms = (JoinMultiplayerScreen) screen;
        ServerSelectionList   ssl = jms.serverSelectionList;
        if (ssl == null) return true;

        for (int i = 0; i < ssl.children().size(); i++) {
            int rowTop = ssl.getRowTop(i);
            int cbX    = ssl.getX() + CB_MARGIN;
            int cbY    = rowTop + (SERVER_ROW_H - CB_SIZE) / 2;

            if (mouseX >= cbX && mouseX < cbX + CB_SIZE && mouseY >= cbY && mouseY < cbY + CB_SIZE) {
                ServerData sd = jms.servers.get(i);
                if (sd == null) continue;
                String key = normalise(sd.ip);
                if (quickAssignChecked.contains(key)) quickAssignChecked.remove(key);
                else quickAssignChecked.add(key);
                return false; 
            }
        }
        return true; 
    }

    private void enterQuickAssign(String tabId) {
        quickAssignMode  = true;
        quickAssignTabId = tabId;
        quickAssignChecked.clear();
        panelOpen = false;
        slideProgress = 0f;

        JoinMultiplayerScreen jms = (JoinMultiplayerScreen) screen;
        ServerList sl = jms.servers;
        if (sl != null) {
            sl.load();
            for (int i = 0; i < sl.size(); i++) {
                ServerData sd = sl.get(i);
                if (sd != null && TabConfig.getInstance().serverInTab(sd.ip, tabId)) {
                    quickAssignChecked.add(normalise(sd.ip));
                }
            }
            jms.serverSelectionList.updateOnlineServers(sl);
        }
        
        if (deselectAllButton != null) deselectAllButton.visible = true;
        refreshToggleLabel();
    }

    private void commitQuickAssign() {
        JoinMultiplayerScreen jms = (JoinMultiplayerScreen) screen;
        ServerList sl = jms.servers;
        if (sl != null && quickAssignTabId != null) {
            for (int i = 0; i < sl.size(); i++) {
                ServerData sd = sl.get(i);
                if (sd == null) continue;
                String key = normalise(sd.ip);
                if (quickAssignChecked.contains(key)) TabConfig.getInstance().assignServer(sd.ip, quickAssignTabId, false);
                else TabConfig.getInstance().unassignServer(sd.ip, quickAssignTabId, false);
            }
            TabConfig.getInstance().save(); 
        }

        quickAssignMode    = false;
        quickAssignTabId   = null;
        quickAssignChecked.clear();
        if (deselectAllButton != null) deselectAllButton.visible = false;
        
        refreshToggleLabel();
        applyTabFilter(jms, activeTabId);
    }

    public static void applyTabFilter(JoinMultiplayerScreen jms, String tabId) {
        try {
            ServerList          servers       = jms.servers;
            ServerSelectionList selectionList = jms.serverSelectionList;

            if (servers == null || selectionList == null) return;
            servers.load();

            List<ServerData> originalList = getInternalList(servers);
            if (originalList != null) {
                List<ServerData> filteredList = new ArrayList<>(originalList);

                if (!"all".equals(tabId)) {
                    filteredList.removeIf(sd -> !TabConfig.getInstance().serverInTab(sd.ip, tabId));
                }

                TabConfig.SortingType sortType = TabConfig.getInstance().getSortingType();
                if (sortType == TabConfig.SortingType.ALPHABETICAL) {
                    filteredList.sort((a, b) -> {
                        String nameA = a.name == null ? "" : a.name.toLowerCase(Locale.ROOT);
                        String nameB = b.name == null ? "" : b.name.toLowerCase(Locale.ROOT);
                        return nameA.compareTo(nameB);
                    });
                }

                setInternalList(servers, filteredList);
                selectionList.updateOnlineServers(servers);
                setInternalList(servers, originalList);
            }
        } catch (Exception e) {}
    }

    @SuppressWarnings("unchecked")
    private static List<ServerData> getInternalList(ServerList sl) {
        try {
            for (Field f : sl.getClass().getDeclaredFields()) {
                if (List.class.isAssignableFrom(f.getType())) {
                    f.setAccessible(true);
                    return (List<ServerData>) f.get(sl);
                }
            }
        } catch (Exception e) {}
        return null;
    }

    private static void setInternalList(ServerList sl, List<ServerData> list) {
        try {
            for (Field f : sl.getClass().getDeclaredFields()) {
                if (List.class.isAssignableFrom(f.getType())) {
                    f.setAccessible(true);
                    f.set(sl, list);
                    return;
                }
            }
        } catch (Exception e) {}
    }

    public static boolean isAltDownFallback() {
        try {
            Object windowObj = Minecraft.getInstance().getWindow();
            long handle = 0;
            for (Method m : windowObj.getClass().getMethods()) {
                if (m.getReturnType() == long.class && m.getParameterCount() == 0 && (m.getName().equals("getWindow") || m.getName().equals("getHandle"))) {
                    handle = (long) m.invoke(windowObj);
                    break;
                }
            }
            if (handle == 0) {
                for (Field f : windowObj.getClass().getDeclaredFields()) {
                    if (f.getType() == long.class) {
                        f.setAccessible(true);
                        handle = (long) f.get(windowObj);
                        break;
                    }
                }
            }
            return GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS || 
                   GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_RIGHT_ALT) == GLFW.GLFW_PRESS;
        } catch (Exception e) {
            return false;
        }
    }

    private void refreshToggleLabel() {
        if (toggleButton == null) return;
        if (quickAssignMode) { toggleButton.setMessage(Component.literal("Done \u2713")); return; }
        List<TabEntry> tabs = TabConfig.getInstance().getTabs();
        String label = tabs.stream().filter(t -> t.getId().equals(activeTabId)).map(TabEntry::getName).findFirst().orElse("All");
        String arrow = panelOpen ? " \u2191" : " \u2193";
        toggleButton.setMessage(Component.literal(label + arrow));
    }

    private static float easeInOut(float t) { return t * t * (3f - 2f * t); }
    private static String normalise(String ip) { return ip == null ? "" : ip.trim().toLowerCase(Locale.ROOT); }
}
--- END OF FILE ---